import { Component, OnInit } from "@angular/core";
import { LoginForm } from "src/app/core/models/login.model";
import { AuthService } from "src/app/core/services/auth.service";
import { EncryptdecryptService } from "src/app/core/services/encryptdecrypt.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  LoginForm: LoginForm = new LoginForm();
  userValid: boolean;
  userParam: any;
  constructor(
    private authService: AuthService,
    private encryptdecryptService: EncryptdecryptService,
    private router: Router
  ) {}

  ngOnInit() {}
  onLogin() {
    const email = this.LoginForm.email;
    const passowrd = this.LoginForm.password;
    this.userParam = {
      email: email,
      passowrd: passowrd,
    };
    this.authService.UserLogin(email, passowrd).subscribe((response) => {
      if (response) {
        this.setLocalStorage();
      } else {
        return;
      }
    });
  }
  setLocalStorage() {
    this.encryptdecryptService.setEncryptLocalSotrage(
      "UserInfo",
      this.userParam
    );
    this.router.navigate(["page/home"]);
  }
}
