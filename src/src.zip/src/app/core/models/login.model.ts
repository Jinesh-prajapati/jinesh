export class LoginForm {
  email: string;
  password: string;
}
