import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { EncryptdecryptService } from "./encryptdecrypt.service";
import { Router } from "@angular/router";

@Injectable({
  providedIn: "root",
})
export class AuthService {
  constructor(
    private encryptDecrypt: EncryptdecryptService,
    private router: Router
  ) {}

  UserLogin(email, password): Observable<boolean> {
    if (email && password) {
      return of(true);
    } else {
      return of(false);
    }
  }
  logout() {
    this.encryptDecrypt.removeencryptDecrypt("UserInfo");
    this.router.navigate(["/auth/login"]);
  }
}
