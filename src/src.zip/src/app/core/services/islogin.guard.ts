import { Injectable } from "@angular/core";
import {
  CanActivateChild,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
} from "@angular/router";
import { Observable } from "rxjs";
import { EncryptdecryptService } from "./encryptdecrypt.service";

@Injectable({
  providedIn: "root",
})
export class IsloginGuard implements CanActivateChild {
  constructor(
    private encryptDecrpt: EncryptdecryptService,
    private router: Router
  ) {}
  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    if (this.encryptDecrpt.getDecryptLocalStorage("UserInfo")) {
      this.router.navigate(["/page/home"]);
      return false;
    } else {
      return true;
    }
  }
}
