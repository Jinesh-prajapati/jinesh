import { Injectable, Inject } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class LocalStorageService {
  constructor(@Inject("LOCALSTORAGE") public localStorage: Storage) {}

  setLocal(key: string, data: string) {
    this.localStorage.setItem(key, data);
  }
  getLocal(key: string) {
    return localStorage.getItem(key);
  }
  remove(key) {
    localStorage.removeItem(key);
  }
}
