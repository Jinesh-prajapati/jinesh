import { Injectable } from "@angular/core";
import { AES, enc } from "crypto-js";
import { LocalStorageService } from "./local-storage.service";
@Injectable({
  providedIn: "root",
})
export class EncryptdecryptService {
  constructor(private localStorageService: LocalStorageService) {}
  secretkey: string = "TestAngular";
  initialKey: string = "TestUser";
  encrypt(data: any) {
    return AES.encrypt(JSON.stringify(data), this.secretkey);
  }
  decrypt(data: any) {
    let byte = AES.decrypt(data.toString(), this.secretkey);
    if (byte) {
      return JSON.parse(byte.toString(enc.Utf8));
    }
  }
  setEncryptLocalSotrage(key: string, data: any) {
    const storageKey = this.initialKey + "-" + key.trim();
    const encryptData = this.encrypt(data);
    this.localStorageService.setLocal(storageKey, encryptData);
  }
  getDecryptLocalStorage(key: string) {
    const storageKey = this.initialKey + "-" + key.trim();
    const encryptData = this.localStorageService.getLocal(storageKey);
    if (encryptData) {
      return this.decrypt(encryptData);
    }
  }
  removeencryptDecrypt(key: string) {
    const storageKey = this.initialKey + "-" + key.trim();
    this.localStorageService.remove(storageKey);
  }
}
