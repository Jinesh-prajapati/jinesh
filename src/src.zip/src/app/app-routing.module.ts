import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "./core/services/auth.guard";
import { IsloginGuard } from "./core/services/islogin.guard";

const routes: Routes = [
  {
    path: "auth",
    loadChildren: () =>
      import("../app/auth/auth.module").then((m) => m.AuthModule),
    canActivateChild: [IsloginGuard],
  },
  {
    path: "page",
    loadChildren: () =>
      import("../app/pages/pages.module").then((m) => m.PagesModule),
    canActivate: [AuthGuard],
  },
  {
    path: "",
    redirectTo: "auth",
    pathMatch: "full",
  },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {
  constructor() {}
}
